# Python Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxen/puppet-python.png?branch=master)](https://travis-ci.org/boxen/puppet-python)

## Usage

For now this is lightweight.
We'll want to add virtualenv support someday.

```puppet
include python
```

## Required Puppet Modules

* `boxen`
* `homebrew`
* `stdlib`
* `xquartz`
